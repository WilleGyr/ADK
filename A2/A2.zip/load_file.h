#ifndef LOAD_FILE_H
#define LOAD_FILE

#define MAX_NUM_ELEMENTS		100000

int* load_file(const char* fName);

#endif
