#ifndef A2_Ex1_h
#define A2_Ex1_h

void insertion_sort(int A[], int n);
void merge_sort(int A[], int p, int r);
void quick_sort(int A[], int p, int r);

#endif
