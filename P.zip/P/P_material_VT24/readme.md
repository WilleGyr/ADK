Naming convention for TXT files:
- Files named g...txt are for P_Ex1.
- Files named h...txt are for P_Ex2.
- The number following "g" or "h" indicates the index of the file (corresponding to the map or grid name in the project description).
- The number following the hyphen (-) indicates the number of rows and columns in each file (e.g., number of vertices of graphs for P_Ex1).

Format of TXT Files' Data:
- Values in each row are delimited by a single space (" ").
